#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion


//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class ButtonStrategy : Strategy
	{	
		private System.Windows.Controls.RowDefinition	addedRow;
		private Gui.Chart.ChartTab						chartTab;
		private Gui.Chart.Chart							chartWindow;
		private System.Windows.Controls.Grid			chartTraderGrid, chartTraderButtonsGrid, lowerButtonsGrid;
		private System.Windows.Controls.Button			buyButton, sellButton, beButton, closeButton, slfButton, ssButton, lineButton, newsButton;
		private bool									panelActive;
		private System.Windows.Controls.TabItem			tabItem;
		
		private int tickCount;
		
		private bool buyButtonClicked;
		private bool sellButtonClicked;
		private bool beButtonClicked;
		private bool closeButtonClicked;
		private bool slfButtonClicked;
		private bool ssButtonClicked;
		private bool lineButtonClicked;
		private bool newsButtonClicked;
		
		private int lineButtonCount;
		
		private bool countOnce;
		private bool startTS;
		
		private Order tsOrder1;
		private Order tsOrder2;
		
		private double currentPrice;
		
		private double lastEntry;
		private double lastTP;
		private double lastSL;
		private double lastTPpips;
		private double lastSLpips;
		private double lastRR;
		private double lastLots;
		
		private bool editorder;
		
		private System.Windows.Forms.Timer myTimer = new System.Windows.Forms.Timer();
		
		protected override void OnStateChange()
		{			
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "ButtonStrategy";
				Calculate									= Calculate.OnEachTick;
				EntriesPerDirection							= 2;
				EntryHandling								= EntryHandling.UniqueEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= true;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				
				ButtonOffColor		= Brushes.Blue;
				TextOffColor		= Brushes.White;
				ButtonOnColor		= Brushes.Red;
				TextOnColor			= Brushes.Orange;
				
				Risk				= 1;
				RR					= 1;
				SL					= 50;
				BEcolor				= Brushes.Orange;
				BElength			= 10;
				BEwidth				= 1;
				TStrigger			= 10;
				TSdistance			= 15;
			}
			else if (State == State.Configure){
				buyButtonClicked 	= false;
				sellButtonClicked 	= false;
				beButtonClicked 	= false;
				closeButtonClicked 	= false;
				slfButtonClicked 	= false;
				ssButtonClicked 	= false;
				lineButtonClicked 	= false;
				lineButtonCount		= 0;
				newsButtonClicked 	= false;
				tickCount			= 0;
				startTS				= false;
				currentPrice 		= 0.0;
				editorder 			= false;
				
				lastEntry = 0.0;
				lastTP= 0.0;
				lastSL= 0.0;
				
				myTimer.Tick += new EventHandler(TimerEventProcessor);
				myTimer.Interval = 1000;
				myTimer.Start();
			}
			else if (State == State.Historical)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync(() =>
					{
						CreateWPFControls();
					});
				}
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync(() =>
					{
						DisposeWPFControls();
					});
				}
				myTimer.Dispose();
			}
		}
		
		protected void CreateWPFControls()
		{
			chartWindow				= Window.GetWindow(ChartControl.Parent) as Gui.Chart.Chart;

			// if not added to a chart, do nothing
			if (chartWindow == null)
				return;

			// this is the entire chart trader area grid
			chartTraderGrid			= (chartWindow.FindFirst("ChartWindowChartTraderControl") as Gui.Chart.ChartTrader).Content as System.Windows.Controls.Grid;

			// this grid contains the existing chart trader buttons
			chartTraderButtonsGrid	= chartTraderGrid.Children[0] as System.Windows.Controls.Grid;

			// this grid is to organize stuff below
			lowerButtonsGrid = new System.Windows.Controls.Grid();
			
			//Makes 2 Columns
			lowerButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());
			lowerButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());
			
			//Makes Rows
			for (int i=0; i<5; i++)
				lowerButtonsGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition());
			
			
			addedRow = new System.Windows.Controls.RowDefinition() { Height = new GridLength(150) };
				
			// this style (provided by NinjaTrader_MichaelM) gives the correct default minwidth (and colors) to make buttons appear like chart trader buttons
			Style basicButtonStyle	= Application.Current.FindResource("BasicEntryButton") as Style;
			
			buyButton = new System.Windows.Controls.Button()
			{	
				Content			= string.Format("BUY"),
				Height			= 25,
				Margin			= new Thickness(5,0,5,0),
				Padding			= new Thickness(0,0,0,0),
				Style			= basicButtonStyle
			};
			
			sellButton = new System.Windows.Controls.Button()
			{
				Content			= string.Format("SELL"),
				Height			= 25,
				Margin			= new Thickness(5,0,5,0),
				Padding			= new Thickness(0,0,0,0),
				Style			= basicButtonStyle
			};	
			
			beButton = new System.Windows.Controls.Button()
			{	
				Content			= string.Format("BE"),
				Height			= 25, 
				Margin			= new Thickness(5,0,5,0),
				Padding			= new Thickness(0,0,0,0),
				Style			= basicButtonStyle
			};		
			
			closeButton = new System.Windows.Controls.Button()
			{	
				Content			= string.Format("CLOSE"),
				Height			= 25,
				Margin			= new Thickness(5,0,5,0),
				Padding			= new Thickness(0,0,0,0),
				Style			= basicButtonStyle
			};		
			
			slfButton = new System.Windows.Controls.Button()
			{	
				Content			= "SLF",
				Height			= 25, 
				Margin			= new Thickness(5,0,5,0),
				Padding			= new Thickness(0,0,0,0),
				Style			= basicButtonStyle
			};		
			
			ssButton = new System.Windows.Controls.Button()
			{	
				Content			= "SS",
				Height			= 25, 
				Margin			= new Thickness(5,0,5,0),
				Padding			= new Thickness(0,0,0,0),
				Style			= basicButtonStyle
			};		
			
			lineButton = new System.Windows.Controls.Button()
			{	
				Content			= "LINES",
				Height			= 25, 
				Margin			= new Thickness(5,0,5,0),
				Padding			= new Thickness(0,0,0,0),
				Style			= basicButtonStyle
			};
			
			newsButton = new System.Windows.Controls.Button()
			{	
				Content			= "NEWS",
				Height			= 25, 
				Margin			= new Thickness(5,0,5,0),
				Padding			= new Thickness(0,0,0,0),
				Style			= basicButtonStyle
			};
		
			buyButton.Background	= ButtonOffColor;			
			buyButton.Foreground    = TextOffColor;	
			buyButton.BorderThickness = new Thickness(2.0);
			
			sellButton.Background	= ButtonOffColor;			
			sellButton.Foreground   = TextOffColor;	
			sellButton.BorderThickness = new Thickness(2.0);
			
			beButton.Background		= ButtonOffColor;			
			beButton.Foreground    	= TextOffColor;	
			beButton.BorderThickness = new Thickness(2.0);
			
			closeButton.Background	= ButtonOffColor;			
			closeButton.Foreground  = TextOffColor;	
			closeButton.BorderThickness = new Thickness(2.0);
			
			slfButton.Background	= ButtonOffColor;
			slfButton.Foreground    = TextOffColor;	
			slfButton.BorderThickness = new Thickness(2.0);
			
			ssButton.Background		= ButtonOffColor;
			ssButton.Foreground     = TextOffColor;	
			ssButton.BorderThickness = new Thickness(2.0);
			
			lineButton.Background	= ButtonOffColor;
			lineButton.Foreground   = TextOffColor;	
			lineButton.BorderThickness = new Thickness(2.0);
			
			newsButton.Background	= ButtonOffColor;
			newsButton.Foreground   = TextOffColor;	
			newsButton.BorderThickness = new Thickness(2.0);
			
			buyButton.Click 	+=  buyButtonClick;
			sellButton.Click 	+=  sellButtonClick;
			beButton.Click 		+=  beButtonClick;
			closeButton.Click 	+=  closeButtonClick;
			slfButton.Click 	+=  slfButtonClick;
			ssButton.Click 		+=  ssButtonClick;
			lineButton.Click	+=  lineButtonClick;
//			newsButton.Click 	+=  newsButtonClick;
			
			System.Windows.Controls.Grid.SetColumn(buyButton, 0);
			System.Windows.Controls.Grid.SetRow(buyButton, 1);
			System.Windows.Controls.Grid.SetColumn(sellButton, 1);
			System.Windows.Controls.Grid.SetRow(sellButton, 1);
			System.Windows.Controls.Grid.SetColumn(beButton, 0);
			System.Windows.Controls.Grid.SetRow(beButton, 2);
			System.Windows.Controls.Grid.SetColumn(closeButton, 1);
			System.Windows.Controls.Grid.SetRow(closeButton, 2);
			System.Windows.Controls.Grid.SetColumn(slfButton, 0);
			System.Windows.Controls.Grid.SetRow(slfButton, 3);
			System.Windows.Controls.Grid.SetColumn(ssButton, 1);
			System.Windows.Controls.Grid.SetRow(ssButton, 3);
			System.Windows.Controls.Grid.SetColumn(lineButton, 0);
			System.Windows.Controls.Grid.SetRow(lineButton, 4);
			System.Windows.Controls.Grid.SetColumn(newsButton, 1);
			System.Windows.Controls.Grid.SetRow(newsButton, 4);
			
			lowerButtonsGrid.Children.Add(buyButton);
			lowerButtonsGrid.Children.Add(sellButton);
			lowerButtonsGrid.Children.Add(beButton);
			lowerButtonsGrid.Children.Add(closeButton);
			lowerButtonsGrid.Children.Add(slfButton);
			lowerButtonsGrid.Children.Add(ssButton);
			lowerButtonsGrid.Children.Add(lineButton);
			lowerButtonsGrid.Children.Add(newsButton);
				
			if (TabSelected())	InsertWPFControls();

			chartWindow.MainTabControl.SelectionChanged += TabChangedHandler;
		}
		
		public void InsertWPFControls()
		{
			if (panelActive)	return;
			chartTraderGrid.RowDefinitions.Add(addedRow);
			System.Windows.Controls.Grid.SetRow(lowerButtonsGrid, (chartTraderGrid.RowDefinitions.Count - 1));
			chartTraderGrid.Children.Add(lowerButtonsGrid);
			panelActive = true;
		}
		
		protected void RemoveWPFControls()
		{
			if (!panelActive)	return;			
			if (chartTraderButtonsGrid != null || lowerButtonsGrid != null)
			{
				chartTraderGrid.Children.Remove(lowerButtonsGrid);
				chartTraderGrid.RowDefinitions.Remove(addedRow);
			}
			panelActive = false;			
		}

		private void DisposeWPFControls()
		{	
			if (chartWindow != null)			chartWindow.MainTabControl.SelectionChanged -= TabChangedHandler;			
			if (buyButton != null)				buyButton.Click -= buyButtonClick;
			if (sellButton != null)				sellButton.Click -= sellButtonClick;
			if (beButton != null)				beButton.Click -= beButtonClick;
			if (closeButton != null)			closeButton.Click -= closeButtonClick;
			if (slfButton != null)				slfButton.Click -= slfButtonClick;
			if (ssButton != null)				ssButton.Click -= ssButtonClick;
			if (lineButton != null)				lineButton.Click -= lineButtonClick;
//			if (newsButton != null)				newsButton.Click -= newsButtonClick;
			RemoveWPFControls();		
		}

		private bool TabSelected()
		{
			bool tabSelected = false;
			// loop through each tab and see if the tab this indicator is added to is the selected item
			foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items)
				if ((tab.Content as Gui.Chart.ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem)
					tabSelected = true;

			return tabSelected;
		}
		
		private void TabChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{			
			if (e.AddedItems.Count <= 0)
				return;

			tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
			if (tabItem == null)
				return;

			chartTab = tabItem.Content as Gui.Chart.ChartTab;
			if (chartTab == null)
				return;

			if (TabSelected())
				InsertWPFControls();
			else
				RemoveWPFControls();
		}
		
		protected override void OnBarUpdate()
		{
			currentPrice = Close[0];
			if (State == State.Historical)		return;
			
			if (Position.MarketPosition == MarketPosition.Flat){
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync(() =>
					{
						buyButton.Background = ButtonOffColor;
						buyButton.Foreground = TextOffColor;						
						sellButton.Background = ButtonOffColor;
						sellButton.Foreground = TextOffColor;
						beButton.Background = ButtonOffColor;
						beButton.Foreground = TextOffColor;
						ssButton.Background = ButtonOffColor;
						ssButton.Foreground = TextOffColor;
						slfButton.Background = ButtonOffColor;
						slfButton.Foreground = TextOffColor;	
						lineButton.Background = ButtonOffColor;
						lineButton.Foreground = TextOffColor;	
					});
				}
			}
			
			if (startTS){
				Print("start TS");
				if (Position.MarketPosition == MarketPosition.Long)
				{
					if (Close[0] > Close[1])
					{
						ExitLongLimit(Close[0] - TSdistance * TickSize, "ts1", "long1");
						ExitLongLimit(Close[0] - TSdistance * TickSize, "ts2", "long2");
					}
				}
				if (Position.MarketPosition == MarketPosition.Short)
				{
					if (Close[0] < Close[1])
					{
						ExitShortLimit(Close[0] + TSdistance * TickSize, "ts1", "short1");
						ExitShortLimit(Close[0] + TSdistance * TickSize, "ts2", "short2");
					}
				}
			}
		}
		
		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string nativeError)
		{
			if(order.Name == "ts1")
			{
				tsOrder1 = order;	
			}
			if(order.Name == "ts2")
			{
				tsOrder2 = order;	
			}
		}

		private void TimerEventProcessor(Object myObject, EventArgs myEventArgs)
		{
			/* Important to use the TriggerCustomEvent() to ensure that NinjaScript indexes and pointers are correctly set.
			Do not process your code here. Process your code in the MyCustomHandler method. */
			TriggerCustomEvent(MyCustomHandler, 0, myTimer.Interval);
		}
		
		private void MyCustomHandler(object state)
		{
			// Informs us of when the event was triggered and of our Timer settings
//			Print("\tTime: " + DateTime.Now);
//			Print("\tTimer Interval: " + state.ToString() + "ms");
			
			if (DrawObjects.Count > 0 && editorder == true)
            {
                foreach (DrawingTool draw in DrawObjects.ToList())
                {    
                    if (draw is DrawingTools.Line)
                    {
                        DrawingTools.Line temp = draw as DrawingTools.Line;
						if (draw.Tag == "SLLevel" && lastSL != temp.StartAnchor.Price)
						{
							Print("SLLevel");
							RemoveDrawObjects();
							
							MasterInstrument mi = Bars.Instrument.MasterInstrument;
							double commPerUnit = this.Account.Commission.ByMasterInstrument[mi].PerUnit;
							
							double newSL = (lastEntry-temp.StartAnchor.Price) / TickSize;
							double TpPips = lastRR * newSL;
							double totalCapital = Account.Get(AccountItem.CashValue, Currency.UsDollar);
							double riskAmount = Risk * totalCapital / 100.0;
							double lots = riskAmount / (newSL * Instrument.MasterInstrument.PointValue + commPerUnit);
								
							if (lots % 2 != 0) {
								if (Math.Round(lots) % 2 == 0)
									if (Math.Round(lots) > lots)
										lots = Math.Round(lots) -2;
									if (Math.Round(lots) < lots)
										lots = Math.Round(lots);
								else if (Math.Round(lots) % 2 == 1)
									lots = Math.Round(lots) - 1;
							}
							
							double entryP = lastEntry;
							double TPLevel = entryP + TpPips * TickSize;
							double SLLevel = temp.StartAnchor.Price;
							
							Draw.Rectangle(this, "TPArea", true, 0, TPLevel, -BElength*5, entryP, Brushes.Green, Brushes.Green, 50);
							Draw.Rectangle(this, "SLArea", true, 0, SLLevel, -BElength*5, entryP, Brushes.Red, Brushes.Red, 50);
							Draw.Line(this, "entryLevel", false, 0, entryP, -BElength*5, entryP, Brushes.Gray, DashStyleHelper.Solid, 5);
							Draw.Line(this, "TPLevel", false, 0, TPLevel, -BElength*5, TPLevel, Brushes.Green, DashStyleHelper.Solid, 5);
							Draw.Line(this, "SLLevel", false, 0, SLLevel, -BElength*5, SLLevel, Brushes.Red, DashStyleHelper.Solid, 5);
							Draw.Text(this, "TPLevelLabel", "+$" + (Instrument.MasterInstrument.PointValue * TpPips).ToString() + " / +" + TpPips.ToString() + "pts", -BElength*2, TPLevel+5*TickSize, Brushes.Green);
							Draw.Text(this, "SLLevelLabel", "-$" + (Instrument.MasterInstrument.PointValue * newSL).ToString() + " / -" + newSL.ToString() + "pts", -BElength*2, SLLevel-5*TickSize, Brushes.Red);
							Draw.Text(this, "RR,Lots", "RR: " + RR.ToString() + ", Lots: " + lots.ToString(), -BElength*6, entryP, Brushes.Blue);
							
							lastEntry = entryP;
							lastTP = TPLevel;
							lastSL = SLLevel;
							lastTPpips = TpPips;
							lastSLpips = newSL;
							lastRR = lastRR;
							lastLots = lots;
						}
						
						if (draw.Tag == "TPLevel" && lastTP != temp.StartAnchor.Price)
						{
							Print("TPLevel");
							RemoveDrawObjects();
							
//							Print(lastEntry);
//							Print(lastTP);
//							Print(lastSL);
//							Print(lastTPpips);
//							Print(lastSLpips);
//							Print(lastRR);
//							Print(lastLots);
							
							double newRR = ((temp.StartAnchor.Price - lastEntry) / TickSize) / ((lastEntry-lastSL) / TickSize);
							
							MasterInstrument mi = Bars.Instrument.MasterInstrument;
							double commPerUnit = this.Account.Commission.ByMasterInstrument[mi].PerUnit;
							
							double TpPips = newRR * lastSLpips;				
							double totalCapital = Account.Get(AccountItem.CashValue, Currency.UsDollar);
							double riskAmount = Risk * totalCapital / 100.0;
							double lots = riskAmount / (lastSLpips * Instrument.MasterInstrument.PointValue + commPerUnit);
							
							if (lots % 2 != 0) {
								if (Math.Round(lots) % 2 == 0)
									if (Math.Round(lots) > lots)
										lots = Math.Round(lots) -2;
									if (Math.Round(lots) < lots)
										lots = Math.Round(lots);
								else if (Math.Round(lots) % 2 == 1)
									lots = Math.Round(lots) - 1;
							}
							
							double entryP = lastEntry;
							double TPLevel = temp.StartAnchor.Price;
							double SLLevel = lastSL;
							
							Draw.Rectangle(this, "TPArea", true, 0, TPLevel, -BElength*5, entryP, Brushes.Green, Brushes.Green, 50);
							Draw.Rectangle(this, "SLArea", true, 0, SLLevel, -BElength*5, entryP, Brushes.Red, Brushes.Red, 50);
							Draw.Line(this, "entryLevel", false, 0, entryP, -BElength*5, entryP, Brushes.Gray, DashStyleHelper.Solid, 5);
							Draw.Line(this, "TPLevel", false, 0, TPLevel, -BElength*5, TPLevel, Brushes.Green, DashStyleHelper.Solid, 5);
							Draw.Line(this, "SLLevel", false, 0, SLLevel, -BElength*5, SLLevel, Brushes.Red, DashStyleHelper.Solid, 5);
							Draw.Text(this, "TPLevelLabel", "+$" + (Instrument.MasterInstrument.PointValue * TpPips).ToString() + " / +" + TpPips.ToString() + "pts", -BElength*2, TPLevel+5*TickSize, Brushes.Green);
							Draw.Text(this, "SLLevelLabel", "-$" + (Instrument.MasterInstrument.PointValue * lastSLpips).ToString() + " / -" + lastSLpips.ToString() + "pts", -BElength*2, SLLevel-5*TickSize, Brushes.Red);
							Draw.Text(this, "RR,Lots", "RR: " + newRR.ToString() + ", Lots: " + lots.ToString(), -BElength*6, entryP, Brushes.Blue);
							
							lastEntry = entryP;
							lastTP = TPLevel;
							lastSL = SLLevel;
							lastTPpips = TpPips;
							lastSLpips = lastSLpips;
							lastRR = newRR;
							lastLots = lots;
						}
						
						if (draw.Tag == "entryLevel" && lastEntry != temp.StartAnchor.Price)
						{
							Print("entryLevel");
							RemoveDrawObjects();
							
							MasterInstrument mi = Bars.Instrument.MasterInstrument;
							double commPerUnit = this.Account.Commission.ByMasterInstrument[mi].PerUnit;
							
							double TpPips = lastRR * lastSLpips;				
							double totalCapital = Account.Get(AccountItem.CashValue, Currency.UsDollar);
							double riskAmount = Risk * totalCapital / 100.0;
							double lots = riskAmount / (lastSLpips * Instrument.MasterInstrument.PointValue + commPerUnit);
							
							if (lots % 2 != 0) {
								if (Math.Round(lots) % 2 == 0)
									if (Math.Round(lots) > lots)
										lots = Math.Round(lots) -2;
									if (Math.Round(lots) < lots)
										lots = Math.Round(lots);
								else if (Math.Round(lots) % 2 == 1)
									lots = Math.Round(lots) - 1;
							}
							
							double entryP = temp.StartAnchor.Price;
							double TPLevel = entryP + TpPips * TickSize;
							double SLLevel = entryP - lastSLpips * TickSize;
							
							Draw.Rectangle(this, "TPArea", true, 0, TPLevel, -BElength*5, entryP, Brushes.Green, Brushes.Green, 50);
							Draw.Rectangle(this, "SLArea", true, 0, SLLevel, -BElength*5, entryP, Brushes.Red, Brushes.Red, 50);
							Draw.Line(this, "entryLevel", false, 0, entryP, -BElength*5, entryP, Brushes.Gray, DashStyleHelper.Solid, 5);
							Draw.Line(this, "TPLevel", false, 0, TPLevel, -BElength*5, TPLevel, Brushes.Green, DashStyleHelper.Solid, 5);
							Draw.Line(this, "SLLevel", false, 0, SLLevel, -BElength*5, SLLevel, Brushes.Red, DashStyleHelper.Solid, 5);
							Draw.Text(this, "TPLevelLabel", "+$" + (Instrument.MasterInstrument.PointValue * TpPips).ToString() + " / +" + TpPips.ToString() + "pts", -BElength*2, TPLevel+5*TickSize, Brushes.Green);
							Draw.Text(this, "SLLevelLabel", "-$" + (Instrument.MasterInstrument.PointValue * lastSLpips).ToString() + " / -" + lastSLpips.ToString() + "pts", -BElength*2, SLLevel-5*TickSize, Brushes.Red);
							Draw.Text(this, "RR,Lots", "RR: " + RR.ToString() + ", Lots: " + lots.ToString(), -BElength*6, entryP, Brushes.Blue);
							
							lastEntry = entryP;
							lastTP = TPLevel;
							lastSL = SLLevel;
							lastTPpips = TpPips;
							lastSLpips = lastSLpips;
							lastRR = lastRR;
							lastLots = lots;
						}     
                    }
                }
            }
			
		}
		protected void buyButtonClick(object sender, RoutedEventArgs e)
		{
			ForceRefresh();
			
			MasterInstrument mi = Bars.Instrument.MasterInstrument;
			double commPerUnit = this.Account.Commission.ByMasterInstrument[mi].PerUnit;
			Print("commission///" + commPerUnit);
			
			if (Position.MarketPosition == MarketPosition.Flat)
			{
				double TpPips = RR * SL;
				
				double totalCapital = Account.Get(AccountItem.CashValue, Currency.UsDollar);
				double riskAmount = Risk * totalCapital / 100.0;
				double lots = riskAmount / (SL * Instrument.MasterInstrument.PointValue + commPerUnit);
				Print("lots////"+lots);
				
				if (lots % 2 != 0) {
					if (Math.Round(lots) % 2 == 0)
						if (Math.Round(lots) > lots)
							lots = Math.Round(lots) -2;
						if (Math.Round(lots) < lots)
							lots = Math.Round(lots);
					else if (Math.Round(lots) % 2 == 1)
						lots = Math.Round(lots) - 1;
				}
				
				if (lots >= 2){
					EnterLong((int)lots/2, "long1");
					SetStopLoss("long1", CalculationMode.Pips, SL, false);
					SetProfitTarget("long1", CalculationMode.Pips, TpPips);
					
					EnterLong((int)lots/2, "long2");
					SetStopLoss("long2", CalculationMode.Pips, SL, false);
					SetProfitTarget("long2", CalculationMode.Pips, TpPips);
	
					buyButton.Background = ButtonOnColor;
					buyButton.Foreground = TextOnColor;
				}
			}
			return;
		}
		
		protected void sellButtonClick(object sender, RoutedEventArgs e)
		{
			ForceRefresh();
			
			MasterInstrument mi = Bars.Instrument.MasterInstrument;
			double commPerUnit = this.Account.Commission.ByMasterInstrument[mi].PerUnit;
			Print("commission///" + commPerUnit);
			
			if (Position.MarketPosition == MarketPosition.Flat)
			{
				double TpPips = RR * SL;
				
				double totalCapital = Account.Get(AccountItem.CashValue, Currency.UsDollar);
				double riskAmount = Risk * totalCapital / 100.0;
				double lots = riskAmount / (SL * Instrument.MasterInstrument.PointValue + commPerUnit);
				
				if (lots % 2 != 0) {
					if (Math.Round(lots) % 2 == 0)
						if (Math.Round(lots) > lots)
							lots = Math.Round(lots) -2;
						if (Math.Round(lots) < lots)
							lots = Math.Round(lots);
					else if (Math.Round(lots) % 2 == 1)
						lots = Math.Round(lots) - 1;
				}
				Print("lots////"+lots);
				
				if (lots >= 2){
					EnterShort((int)lots/2, "short1");
					SetStopLoss("short1", CalculationMode.Pips, SL, false);
					SetProfitTarget("short1", CalculationMode.Pips, TpPips);
					
					EnterShort((int)lots/2, "short2");
					SetStopLoss("short2", CalculationMode.Pips, SL, false);
					SetProfitTarget("short2", CalculationMode.Pips, TpPips);
		
					sellButton.Background = ButtonOnColor;
					sellButton.Foreground = TextOnColor;
				}
			}
			return;
		}
		
		protected void beButtonClick(object sender, RoutedEventArgs e)
		{
			ForceRefresh();			
			double pnl = Account.Get(AccountItem.UnrealizedProfitLoss, Currency.UsDollar);
			
			MasterInstrument mi = Bars.Instrument.MasterInstrument;
			double commPerUnit = this.Account.Commission.ByMasterInstrument[mi].PerUnit;
			Print("commission///" + commPerUnit);
			double newSL = 0.0;
			if (!beButtonClicked && pnl > 0){
				if (Position.MarketPosition == MarketPosition.Long)
				{
					newSL = Position.AveragePrice + commPerUnit / Position.Quantity;
//					Print("ent///"+Position.AveragePrice);
//					Print("sl///"+newSL);
					SetStopLoss("long1", CalculationMode.Price, newSL, false);
					SetStopLoss("long2", CalculationMode.Price, newSL, false);
				}
				else if (Position.MarketPosition == MarketPosition.Short)
				{
					newSL = Position.AveragePrice - commPerUnit / Position.Quantity;
					SetStopLoss("short1", CalculationMode.Price, newSL, false);
					SetStopLoss("short2", CalculationMode.Price, newSL, false);
				}
				Draw.Line(this, "BELine", false, 0, newSL, -BElength, newSL, BEcolor, DashStyleHelper.Dot, BEwidth);
				beButton.Background = ButtonOnColor;
				beButton.Foreground = TextOnColor;
				beButtonClicked = true;
			}
			else if (beButtonClicked){				
				if (Position.MarketPosition == MarketPosition.Long)
				{
					SetStopLoss("long1", CalculationMode.Pips, SL, false);
					SetStopLoss("long2", CalculationMode.Pips, SL, false);
				}
				else if (Position.MarketPosition == MarketPosition.Short)
				{
					SetStopLoss("short1", CalculationMode.Pips, SL, false);
					SetStopLoss("short2", CalculationMode.Pips, SL, false);
				}
				RemoveDrawObjects();
				beButton.Background = ButtonOffColor;
				beButton.Foreground = TextOffColor;
				beButtonClicked = false;
			}
		}
		
		protected void closeButtonClick(object sender, RoutedEventArgs e)
		{
			ForceRefresh();
			if (Position.MarketPosition == MarketPosition.Long){
				ExitLong(Position.Quantity);
				buyButton.Background = ButtonOffColor;
				buyButton.Foreground = TextOffColor;
			}
			if (Position.MarketPosition == MarketPosition.Short){
				ExitShort(Position.Quantity);
				sellButton.Background = ButtonOffColor;
				sellButton.Foreground = TextOffColor;
			}
			beButton.Background = ButtonOffColor;
			beButton.Foreground = TextOffColor;
			beButtonClicked = false;
			
			ssButton.Background = ButtonOffColor;
			ssButton.Foreground = TextOffColor;
			ssButtonClicked = false;
			
			slfButton.Background = ButtonOffColor;
			slfButton.Foreground = TextOffColor;
			slfButtonClicked = false;
			
			lineButton.Background = ButtonOffColor;
			lineButton.Foreground = TextOffColor;
			lineButtonClicked = false;
			RemoveDrawObjects();
			lineButtonCount = 0;
		}
		
		protected void ssButtonClick(object sender, RoutedEventArgs e)
		{
			ForceRefresh();		
			ssButtonClicked = !ssButtonClicked;
			if (ssButtonClicked){				
				double pnl = Account.Get(AccountItem.UnrealizedProfitLoss, Currency.UsDollar);
				if (pnl > TStrigger)
				{
					startTS = true;
					ssButton.Background = ButtonOnColor;
					ssButton.Foreground = TextOnColor;
				}
				else
					ssButtonClicked = !ssButtonClicked;
			}else{
				ssButton.Background = ButtonOffColor;
				ssButton.Foreground = TextOffColor;
				startTS = true;
				CancelOrder(tsOrder1);
				CancelOrder(tsOrder2);
			}
		}
		
		protected void slfButtonClick(object sender, RoutedEventArgs e)
		{
			ForceRefresh();			
			double pnl = Account.Get(AccountItem.UnrealizedProfitLoss, Currency.UsDollar);
			if (pnl > 0 && !slfButtonClicked){
				if (Position.MarketPosition == MarketPosition.Long){
					ExitLong(Position.Quantity/2, "long-slf", "long2");
				}
				else if (Position.MarketPosition == MarketPosition.Short){
					ExitShort(Position.Quantity/2, "short-slf", "short2");
				}
				slfButton.Background = ButtonOnColor;
				slfButton.Foreground = TextOnColor;
				slfButtonClicked = true;
				
				MasterInstrument mi = Bars.Instrument.MasterInstrument;
				double commPerUnit = this.Account.Commission.ByMasterInstrument[mi].PerUnit;
				double newSL = 0.0;

				if (SystemPerformance.RealTimeTrades.Count > 0)
				{					
					Trade lastTrade = SystemPerformance.RealTimeTrades[SystemPerformance.RealTimeTrades.Count - 1];
					double currentTP = lastTrade.ProfitTicks;
					if (Position.MarketPosition == MarketPosition.Long){
						newSL = Position.AveragePrice - currentTP * TickSize + commPerUnit / Position.Quantity;
						SetStopLoss("long1", CalculationMode.Price, newSL, false);
					}
					else if (Position.MarketPosition == MarketPosition.Short){
						newSL = Position.AveragePrice + currentTP * TickSize - commPerUnit / Position.Quantity;
						SetStopLoss("short1", CalculationMode.Price, newSL, false);
					}
					Draw.Line(this, "BELine", false, 0, newSL, -BElength, newSL, BEcolor, DashStyleHelper.Dot, BEwidth);
				}
			}
		}
		
		protected void lineButtonClick(object sender, RoutedEventArgs e)
		{
			ForceRefresh();
			
			lineButtonCount += 1;
			
			if (lineButtonCount == 1)
			{
				lineButton.Background = Brushes.Green;
				lineButton.Foreground = Brushes.Green;
				editorder = true;
								
				MasterInstrument mi = Bars.Instrument.MasterInstrument;
				double commPerUnit = this.Account.Commission.ByMasterInstrument[mi].PerUnit;
				
				double TpPips = RR * SL;				
				double totalCapital = Account.Get(AccountItem.CashValue, Currency.UsDollar);
				double riskAmount = Risk * totalCapital / 100.0;
				double lots = riskAmount / (SL * Instrument.MasterInstrument.PointValue + commPerUnit);
					
				if (lots % 2 != 0) {
					if (Math.Round(lots) % 2 == 0)
						if (Math.Round(lots) > lots)
							lots = Math.Round(lots) -2;
						if (Math.Round(lots) < lots)
							lots = Math.Round(lots);
					else if (Math.Round(lots) % 2 == 1)
						lots = Math.Round(lots) - 1;
				}
				
				double entryP = currentPrice;
				double TPLevel = currentPrice + TpPips * TickSize;
				double SLLevel = currentPrice - SL * TickSize;
				
				Draw.Rectangle(this, "TPArea", true, 0, TPLevel, -BElength*5, entryP, Brushes.Green, Brushes.Green, 50);
				Draw.Rectangle(this, "SLArea", true, 0, SLLevel, -BElength*5, entryP, Brushes.Red, Brushes.Red, 50);
				Draw.Line(this, "entryLevel", false, 0, currentPrice, -BElength*5, currentPrice, Brushes.Gray, DashStyleHelper.Solid, 5);
				Draw.Line(this, "TPLevel", false, 0, TPLevel, -BElength*5, TPLevel, Brushes.Green, DashStyleHelper.Solid, 5);
				Draw.Line(this, "SLLevel", false, 0, SLLevel, -BElength*5, SLLevel, Brushes.Red, DashStyleHelper.Solid, 5);
				Draw.Text(this, "TPLevelLabel", "+$" + (Instrument.MasterInstrument.PointValue * TpPips).ToString() + " / +" + TpPips.ToString() + "pts", -BElength*2, TPLevel+5*TickSize, Brushes.Green);
				Draw.Text(this, "SLLevelLabel", "-$" + (Instrument.MasterInstrument.PointValue * SL).ToString() + " / -" + SL.ToString() + "pts", -BElength*2, SLLevel-5*TickSize, Brushes.Red);
				Draw.Text(this, "RR,Lots", "RR: " + RR.ToString() + ", Lots: " + lots.ToString(), -BElength*6, entryP, Brushes.Blue);
				
				lastEntry = entryP;
				lastTP = TPLevel;
				lastSL = SLLevel;
				lastTPpips = TpPips;
				lastSLpips = SL;
				lastRR= RR;
				lastLots = lots;
			}
			else if (lineButtonCount == 2)
			{
				editorder = false;
				lineButton.Background = ButtonOnColor;
				lineButton.Foreground = TextOnColor;
				
				if (lastTP > lastSL)
				{
					EnterLong((int)lastLots/2, "long1");
					SetStopLoss("long1", CalculationMode.Pips, lastSLpips, false);
					SetProfitTarget("long1", CalculationMode.Pips, lastTPpips);
					
					EnterLong((int)lastLots/2, "long2");
					SetStopLoss("long2", CalculationMode.Pips, lastSLpips, false);
					SetProfitTarget("long2", CalculationMode.Pips, lastTPpips);
					
				}
				else if (lastTP < lastSL)
				{
					EnterShort((int)lastLots/2, "short1");
					SetStopLoss("short1", CalculationMode.Pips, lastSLpips, false);
					SetProfitTarget("short1", CalculationMode.Pips, lastTPpips);
					
					EnterShort((int)lastLots/2, "short2");
					SetStopLoss("short2", CalculationMode.Pips, lastSLpips, false);
					SetProfitTarget("short2", CalculationMode.Pips, lastTPpips);
				}
					
			}
		}
		
		#region Properties
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="ButtonOnColor", Order=1, GroupName="Parameters")]
		public Brush ButtonOnColor
		{ get; set; }

		[Browsable(false)]
		public string ButtonOnColorSerializable
		{
			get { return Serialize.BrushToString(ButtonOnColor); }
			set { ButtonOnColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="TextOnColor", Order=2, GroupName="Parameters")]
		public Brush TextOnColor
		{ get; set; }

		[Browsable(false)]
		public string TextOnColorSerializable
		{
			get { return Serialize.BrushToString(TextOnColor); }
			set { TextOnColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="ButtonOffColor", Order=3, GroupName="Parameters")]
		public Brush ButtonOffColor
		{ get; set; }

		[Browsable(false)]
		public string ButtonOffColorSerializable
		{
			get { return Serialize.BrushToString(ButtonOffColor); }
			set { ButtonOffColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="TextOffColor", Order=4, GroupName="Parameters")]
		public Brush TextOffColor
		{ get; set; }

		[Browsable(false)]
		public string TextOffColorSerializable
		{
			get { return Serialize.BrushToString(TextOffColor); }
			set { TextOffColor = Serialize.StringToBrush(value); }
		}		
		
		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Risk", Description="Risk in %", Order=5, GroupName="Parameters")]
		public double Risk
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="RR", Description="Risk Reward to place target", Order=6, GroupName="Parameters")]
		public double RR
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="SL", Description="points/pips (futures or forex)", Order=7, GroupName="Parameters")]
		public double SL
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="TS Trigger", Description="Ticks", Order=9, GroupName="Parameters")]
		public double TStrigger
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="TS Distance", Description="Ticks", Order=9, GroupName="Parameters")]
		public double TSdistance
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="BEcolor", Description="BE level line color", Order=10, GroupName="Parameters")]
		public Brush BEcolor
		{ get; set; }

		[Browsable(false)]
		public string BEcolorSerializable
		{
			get { return Serialize.BrushToString(BEcolor); }
			set { BEcolor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="BElength", Description="x times the distance between 2 candles, starting at the last candle and going on the right", Order=11, GroupName="Parameters")]
		public int BElength
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="BEwidth", Order=12, GroupName="Parameters")]
		public int BEwidth
		{ get; set; }		
		#endregion
	}
}